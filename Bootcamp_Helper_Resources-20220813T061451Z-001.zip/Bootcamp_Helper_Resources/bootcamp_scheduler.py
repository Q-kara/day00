# Abdur-Raheem Lee <abdur-raheem@wethinkcode.co.za>

def read_file():
    '''
    Reads the contents from the schedule.txt file
    @return the information from the file
    '''


def write_to_file(data_to_write):
    '''
    Update schedule.txt with the information
    '''


def add_host():
    '''
    Get's information about the host and the workshop they would like to host
    Sends the information to be written to the text_file
    '''


def add_attendee():
    '''
    Get's information about the attendee and the workshop they would like to join
    Sends the information to be written to the text_file
    '''


def home_screen():
    '''
    Allows users to choose whether they want to host or attend a workshop
    '''

if __name__ == '__main__':
    home_screen()




